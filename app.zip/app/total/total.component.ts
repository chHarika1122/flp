import { Component, OnInit } from '@angular/core';
import {Customer_Orders} from '../cust';
import {CustService} from '../cust.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-total',
  templateUrl: './total.component.html',
  styleUrls: ['./total.component.css']
})
export class TotalComponent implements OnInit {
  private cust: Customer_Orders[];
  constructor(private router: Router,
    private CustService: CustService) { }

  ngOnInit() {
    this.getAllEmployees();
  }
  getAllEmployees() {
    this.CustService.showOrders(this.cust).then()
  cust => {
    this.cust = cust;
    }
  }
}
