import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpObserve } from '../../node_modules/@angular/common/http/src/client';
import { Observable } from 'rxjs';
import {Customer_Orders} from './cust';
//import 'rxjs/add/operator/toPromise';
@Injectable({
  providedIn: 'root'
})
export class CustService {
  
  private baseUrl = 'http://localhost:3456/total';
  //show balance variable
  
  customer_id : number;
    productName : string;
    orderId : number;
    quantity : number;
    amount : any;


    
  constructor(private http:HttpClient) { }
  
 
  public showOrders(cust) : any  {
    this.customer_id = cust.customerId;
    this.productName = cust.productName;
    this.orderId = cust.orderId;
    this.quantity= cust.quantity;
    this.amount = cust.amount;
    return this.http.get(`${this.baseUrl}/${this.customer_id}/${this.productName}/${this.orderId}/${this.quantity}/${this.amount}`,{responseType : 'text'});

    // return this.http.get(this.baseUrl)
    // .toPromise()
    // .then(response => response.json() as Customer_Orders[])
   
  }

  public cardDetails(card) :Observable<any>{
    return this.http.post(`${this.baseUrl}`+`/card`, card);
  }

  public displayproducts():Observable<any>
  {
    return this.http.get(`http://localhost:3456/showprod`)
  }

  

  


 
 
}
