import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Product } from '../product';
import { Router } from '../../../node_modules/@angular/router';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  product: Product= new Product();
  result : any
  constructor(private router: Router, private service :CustService) { }

  ngOnInit() {
  }

  newUser(): void {
    this.product= new Product();
  }

  
  

}
