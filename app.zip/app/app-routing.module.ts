import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PaymentComponent } from './payment/payment.component';
import { TotalComponent } from './total/total.component';
import { SuccessComponent } from './success/success.component';
import { ProductComponent } from './product/product.component';
import { DisplayproductsComponent } from './displayproducts/displayproducts.component';
const routes: Routes = [
  {
    path: 'payment',
    component: PaymentComponent

  },
  {
    path: 'total',
    component: TotalComponent

  },
  {
    path: 'success',
    component: SuccessComponent

  },
  {
    path: 'product',
    component: ProductComponent

  },
  {
    path: 'dispproduct',
    component: DisplayproductsComponent

  },
  {
    path: '',
    component: DisplayproductsComponent

  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
