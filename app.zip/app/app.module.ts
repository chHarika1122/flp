import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PaymentComponent } from './payment/payment.component';
import { TotalComponent } from './total/total.component';
import { SuccessComponent } from './success/success.component';
//import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { ProductComponent } from './product/product.component';
import { DisplayproductsComponent } from './displayproducts/displayproducts.component';

@NgModule({
  declarations: [
    AppComponent,
    PaymentComponent,
    TotalComponent,
    SuccessComponent,
    ProductComponent,
    DisplayproductsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    //HttpClient,
    //HttpHeaders
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
