export class Customer_Orders{
    customerId : number;
    productName : string;
    orderId : number;
    quantity : number;
    amount : any;
    constructor(customerId: number, productName: string, orderId: number, quantity: number,amount: number){
        this.customerId = customerId;
        this.productName = productName;
        this.orderId = orderId;
        this.quantity = quantity;
        this.amount=amount;
        }
}
