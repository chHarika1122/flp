package com.capgemini.capstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.bean.Carddetails;
import com.capgemini.capstore.bean.CartList;
import com.capgemini.capstore.bean.Customer_Orders;
import com.capgemini.capstore.bean.PriceDetails;
import com.capgemini.capstore.bean.Product;
import com.capgemini.capstore.bean.SearchProduct;
import com.capgemini.capstore.repository.CardRepo;
import com.capgemini.capstore.repository.CartListRepository;
import com.capgemini.capstore.repository.OrderRepo;
import com.capgemini.capstore.repository.PriceDetailRepo;
import com.capgemini.capstore.repository.ProdRepo;
import com.capgemini.capstore.repository.SearchRepo;

@Service
public class IOrderService implements OrderService{

	@Autowired
	OrderRepo repo;
	@Autowired
	CardRepo repo1;
    @Autowired
    ProdRepo repo2;
    @Autowired
    PriceDetailRepo repo3;
    @Autowired
    CartListRepository productrepo;
    @Autowired
    SearchRepo repo4;
	
	@Override
	public List<Customer_Orders> showOrders() {
		// TODO Auto-generated method stub
		List<Customer_Orders> list = new ArrayList<Customer_Orders>();
		list = repo.findAll();
		return list;
	}

	@Override
	public List<Carddetails> showDetails() {
		// TODO Auto-generated method stub
		List<Carddetails> list1 = new ArrayList<Carddetails>();
		list1 = repo1.findAll();
		return list1;
	}

	@Override
	public Carddetails insertCardDetails(Carddetails card) {
			Carddetails entity =  new Carddetails();
			entity.setCardNo(card.getCardNo());
			entity.setCard_holder_name(card.getCard_holder_name());
			entity.setCvv(card.getCvv());
			entity.setExpiry_year(card.getExpiry_year());
			entity.setExpiryMonth(card.getExpiryMonth());
		return repo1.saveAndFlush(card);
	}

	@Override
	public Product addProducts(Product prod) {
		// TODO Auto-generated method stub
		Product entity =  new Product();
		entity.setProdId(prod.getProdId());
		entity.setProdName(prod.getProdName());
		entity.setProdPrice(prod.getProdPrice());
		entity.setProdQuantity(prod.getProdQuantity());
		entity.setProdDiscount(prod.getProdDiscount());
		entity.setProdCategory(prod.getProdCategory());
		entity.setProdDesc(prod.getProdDesc());
		entity.setProdImage(prod.getProdImage());
		entity.setMerchantId(prod.getMerchantId());
	    return repo2.saveAndFlush(prod);
		
	}

	public List<Product> showProductDetails() {
		// TODO Auto-generated method stub
		List<Product> list1 = new ArrayList<Product>();
		list1 = repo2.findAll();
		return list1;
	}

	@Override
	public PriceDetails addPriceDetails(PriceDetails pri) {
		// TODO Auto-generated method stub
		/*
		 * List<PriceDetails> list1 = new ArrayList<PriceDetails>(); list1 =
		 * repo3.findAll();
		 */
		PriceDetails entity =  new PriceDetails();
		entity.setProductId(pri.getProductId());
		entity.setProductName(pri.getProductName());
		entity.setProductPrice(pri.getProductPrice());
		entity.setProductQuantity(pri.getProductQuantity());
		entity.setTotal((long) (pri.getProductPrice()*pri.getProductQuantity()));
		return repo3.saveAndFlush(entity);
		
	}

	@Override
	public List<PriceDetails> showPriceDetails() {
		// TODO Auto-generated method stub
		List<PriceDetails> list1 = new ArrayList<PriceDetails>();
		list1 = repo3.findAll();
		return list1;
	}

	


	
	@Override
	public CartList addToCart(Long prod_Id) {
		/*long quantity=1;
		CartList entity = new CartList();
		
		Product wlist = productrepo.findProduct(prod_Id);
		
		entity.setProdId(wlist.getProd_Id());
		entity.setProd_Category(wlist.getProd_Category());
		entity.setProd_Desc(wlist.getProd_Desc());
		entity.setProd_Discount((int) wlist.getProd_Discount());
		entity.setProd_Image(wlist.getProd_Image());
		entity.setProd_Price(wlist.getProd_Price());
		entity.setProd_Quantity((quantity));
		entity.setProd_Name(wlist.getProd_Name());
		return cartRepo.saveAndFlush(entity);*/
		return null;
	}

	@Override
	public List<CartList> displayCartList(Long cust_Id) {
		List<CartList> list = new ArrayList();
		//list = cartRepo.findAll();
		return list;
	}

	public PriceDetails calculateTotalAmount(Long cust_Id) {
		// TODO Auto-generated method stub
		long total = 0;
		PriceDetails priceentity = new PriceDetails();
		List<CartList> list = productrepo.findProductFromCart(cust_Id);
		for (CartList cartList : list) {
			priceentity.setProductId(cartList.getProdId());
			priceentity.setProductName(cartList.getProd_Name());
			priceentity.setProductQuantity(cartList.getProd_Quantity());
			priceentity.setProductPrice(cartList.getProd_Price());
			total = total+ (long) (cartList.getProd_Quantity() * cartList.getProd_Price());
			priceentity.setTotal(total);
			repo3.saveAndFlush(priceentity);
		}
		
		return priceentity;
	}

	public List<PriceDetails> displayTotalList() {
		List<PriceDetails> list = new ArrayList();
		list = repo3.findAll();
		return list;
	}

	@Override
	public List<SearchProduct> getPriceDetails() {
		// TODO Auto-generated method stub
		List<SearchProduct> list = new ArrayList();
		list = repo4.findAll();
		return list;
	}

	
	

	
}
