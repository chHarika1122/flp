package com.capgemini.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.bean.SearchProduct;

public interface SearchRepo extends JpaRepository<SearchProduct,Integer> {

}
