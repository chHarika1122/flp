import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
   template: `
   <img src="assets/img/bcd.jpg">
 `,
  styleUrls: ['./app.component.css']

})
export class AppComponent {
  title = 'project';
  
}
