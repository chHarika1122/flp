import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  // template: `
  //   <nav class="navbar">

  //     <!-- logo -->
  //     <div class="navbar-brand">
  //       <a class="navbar-item">
  //         <img src="assets/img/bcd.jpg">
  //       </a>
  //     </div>
  //   </nav>
  // `,
  
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
dataset: any;
  constructor() { }

  ngOnInit() {
    this.dataset = ['MDB', 'Angular', 'Bootstrap', 'Framework', 'SPA', 'React', 'Vue'];
  }
  

}
